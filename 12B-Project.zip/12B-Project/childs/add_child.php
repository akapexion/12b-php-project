<?php
    include( __DIR__ . "../../base/header.php");

    if(isset($_POST['add_child'])){
      extract($_POST);

      $insert_query = "INSERT INTO childs(child_name, child_age, child_disease) VALUES('$child_name', $child_age, '$child_disease')";
      $result = mysqli_query($conn, $insert_query);
    }
?>


 <!-- Column 1: Basic controls -->
      <div class="col-12 col-lg-6">
        <form method="POST">
        <div class="card border-light shadow-sm p-4 h-100">
          <h5 class="card-title mb-4">Add Child</h5>

          <!-- Text input -->
          <div class="mb-3">
            <label for="basicText" class="form-label-custom">Child Name</label>
            <input type="text" class="form-control-custom" id="basicText" name="child_name">
          </div>

          <!-- Email input -->
          <div class="mb-3">
            <label for="basicEmail" class="form-label-custom">Child Age</label>
            <input type="number" class="form-control-custom" id="basicEmail" name="child_age">
          </div>

          <!-- Password input -->
          <div class="mb-3">
            <label for="basicPassword" class="form-label-custom">Child Disease</label>
            <input type="text" class="form-control-custom" id="basicPassword"
              name="child_disease">
          </div>

          <div>
            <button name="add_child">SAVE</button>
          </div>

        </div>
        </form>
      </div>


<?php
    include( __DIR__ . "../../base/footer.php");
?>