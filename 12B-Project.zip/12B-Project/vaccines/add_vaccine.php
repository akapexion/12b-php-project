<?php
    include( __DIR__ . "../../base/header.php");

    if(isset($_POST['add_vaccine'])){
      extract($_POST);

      $insert_query = "INSERT INTO `vaccines`( `vaccine_name`, `vaccine_for_disease`, `vaccine_stock`) VALUES ('$vaccine_name', '$vaccine_for_disease', $vaccine_stock)";
      $result = mysqli_query($conn, $insert_query);
    }
?>


 <!-- Column 1: Basic controls -->
      <div class="col-12 col-lg-6">
        <form method="POST">
        <div class="card border-light shadow-sm p-4 h-100">
          <h5 class="card-title mb-4">Add Vaccine</h5>

          <!-- Text input -->
          <div class="mb-3">
            <label for="basicText" class="form-label-custom">Vaccine Name</label>
            <input type="text" class="form-control-custom" id="basicText" name="vaccine_name">
          </div>

          <!-- Text input -->
          <div class="mb-3">
            <label for="basicText" class="form-label-custom">Vaccine For Diseaese</label>
            <input type="text" class="form-control-custom" id="basicText" name="vaccine_for_disease">
          </div>

          <!-- Email input -->
          <div class="mb-3">
            <label for="basicEmail" class="form-label-custom">Vaccine Stock</label>
            <input type="number" class="form-control-custom" id="basicEmail" name="vaccine_stock">
          </div>

          <div>
            <button name="add_vaccine">SAVE</button>
          </div>

        </div>
        </form>
      </div>


<?php
    include( __DIR__ . "../../base/footer.php");
?>