<?php

$conn = mysqli_connect("localhost", "root", "");

$db = mysqli_query($conn, "SHOW DATABASES LIKE 'spark_db'");
$count_dbs = mysqli_num_rows($db);

if($count_dbs > 0){
    echo "Migration already RAN";
}
else {
    mysqli_query($conn, "CREATE DATABASE IF NOT EXISTS spark_db");

    mysqli_query($conn, "use spark_db");

    mysqli_query($conn, "CREATE TABLE IF NOT EXISTS users(
       user_id int AUTO_INCREMENT PRIMARY KEY,
       user_name varchar(50),
       user_email varchar(50),
       user_password varchar(50),
       user_role varchar(50) DEFAULT 'user',
       google_id varchar(150) DEFAULT '---',
       profile_image text(150) DEFAULT '---'
    )");

      mysqli_query($conn, "CREATE TABLE IF NOT EXISTS childs(
       child_id int AUTO_INCREMENT PRIMARY KEY,
       child_name varchar(50),
       child_age varchar(50),
       child_disease varchar(50)
    )");

    mysqli_query($conn, "CREATE TABLE IF NOT EXISTS hospitals(
       hospital_id int AUTO_INCREMENT PRIMARY KEY,
       hospital_name varchar(50),
       hospital_address text(50),
       hospital_status varchar(50)
    )");

    mysqli_query($conn, "CREATE TABLE IF NOT EXISTS vaccines(
       vaccine_id int AUTO_INCREMENT PRIMARY KEY,
       vaccine_name varchar(50),
       vaccine_for_disease varchar(50),
       vaccine_status varchar(50),
       vaccine_stock int
    )");

    mysqli_query($conn, "
        INSERT IGNORE INTO users
(user_name, user_email, user_password, user_role, google_id, profile_image)
VALUES
('Administrator', 'admin@spark.com', sha1('admin123'), 'admin', '---', 'admin.png'),
('Ali Khan', 'ali@gmail.com', sha1('ali123'), 'user', '---', 'ali.png'),
('Sara Ahmed', 'sara@gmail.com', sha1('sara123'), 'user', '---', 'sara.png'),
('Usman Malik', 'usman@gmail.com', sha1('usman123'), 'user', '---', 'usman.png'),
('Ayesha Noor', 'ayesha@gmail.com', sha1('ayesha123'), 'user', '---', 'ayesha.png');
    ");




}
?>